const double PRICE_BAR_WIDTH = 60;
const double DATE_BAR_HEIGHT = 20;
const double MIN_PRICETILE_HEIGHT = 50;
const double MAIN_CHART_VERTICAL_PADDING = 10;
const double PRICE_INDICATOR_HEIGHT = 20;
